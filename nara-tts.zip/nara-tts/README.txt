Nara TTS - offline Burmese Android TTS engine (Nara Mini v1, ONNX)

BUILD (phone-friendly, on GitHub):
1. In your repo: Add file > Upload files > upload nara-tts.zip (do not unzip).
2. Create .github/workflows/build-apk.yml with the contents of build-apk.yml.
3. Actions > Build Nara TTS APK > Run workflow.
4. When green, open Releases > latest build > download NaraTTS.apk and install.

USE:
1. Open Nara TTS, tap a voice to download (about 181 MB, needs internet once).
2. Android Settings > Text-to-speech output > Preferred engine > Nara TTS.
3. Select to Speak now reads Burmese offline.

NOTE: English words are skipped (original needs misaki/eSpeak).
