package com.nara.tts

import android.media.AudioFormat
import android.speech.tts.SynthesisCallback
import android.speech.tts.SynthesisRequest
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeechService
import android.speech.tts.Voice
import java.util.Locale

class NaraTtsService : TextToSpeechService() {

    @Volatile private var stopped = false

    override fun onCreate() {
        super.onCreate()
        // Load the model in the background so the first sentence starts sooner.
        Thread {
            try {
                val v = VoiceStore.currentVoice(this)
                NaraRuntime.ensureEnglish(this)
                if (v != null) NaraRuntime.engine(this).ensureLoaded(v)
            } catch (_: Throwable) {
            }
        }.start()
    }

    private fun isBurmese(lang: String?): Boolean {
        val l = lang?.lowercase(Locale.ROOT) ?: return false
        return l == "mya" || l == "my" || l == "bur"
    }

    override fun onIsLanguageAvailable(lang: String?, country: String?, variant: String?): Int {
        if (!isBurmese(lang)) return TextToSpeech.LANG_NOT_SUPPORTED
        if (VoiceStore.currentVoice(this) == null) return TextToSpeech.LANG_MISSING_DATA
        val c = country?.uppercase(Locale.ROOT) ?: ""
        return if (c == "MMR" || c == "MM") TextToSpeech.LANG_COUNTRY_AVAILABLE else TextToSpeech.LANG_AVAILABLE
    }

    override fun onGetLanguage(): Array<String> = arrayOf("mya", "MMR", "")

    override fun onLoadLanguage(lang: String?, country: String?, variant: String?): Int =
        onIsLanguageAvailable(lang, country, variant)

    override fun onGetVoices(): MutableList<Voice> {
        val list = ArrayList<Voice>()
        for (id in VoiceStore.installed(this)) {
            list.add(
                Voice(
                    "nara-$id", Locale("my", "MM"), Voice.QUALITY_HIGH, Voice.LATENCY_NORMAL,
                    false, HashSet<String>()
                )
            )
        }
        return list
    }

    override fun onGetDefaultVoiceNameFor(lang: String?, country: String?, variant: String?): String? {
        if (!isBurmese(lang)) return null
        val v = VoiceStore.currentVoice(this) ?: return null
        return "nara-$v"
    }

    override fun onIsValidVoiceName(name: String?): Int {
        val id = name?.removePrefix("nara-")
        return if (name != null && name.startsWith("nara-") && id != null && VoiceStore.isInstalled(this, id))
            TextToSpeech.SUCCESS else TextToSpeech.ERROR
    }

    override fun onLoadVoice(name: String?): Int = onIsValidVoiceName(name)

    override fun onStop() {
        stopped = true
    }

    override fun onSynthesizeText(request: SynthesisRequest, callback: SynthesisCallback) {
        stopped = false
        val text = request.charSequenceText?.toString() ?: ""
        if (text.isBlank()) {
            callback.start(NaraEngine.SAMPLE_RATE, AudioFormat.ENCODING_PCM_16BIT, 1)
            callback.done()
            return
        }

        var id = request.voiceName?.removePrefix("nara-")
        if (id == null || !VoiceStore.isInstalled(this, id)) id = VoiceStore.currentVoice(this)
        if (id == null) {
            callback.error(TextToSpeech.ERROR_NOT_INSTALLED_YET)
            return
        }

        // speech rate (percent, 100 = normal) is applied by changing the playback rate
        val rate = request.speechRate.coerceIn(50, 300)
        val sampleRate = NaraEngine.SAMPLE_RATE * rate / 100
        if (callback.start(sampleRate, AudioFormat.ENCODING_PCM_16BIT, 1) != TextToSpeech.SUCCESS) return

        try {
            val maxBuf = callback.maxBufferSize.coerceAtLeast(1024)
            NaraRuntime.engine(this).synthesize(id, text) { pcm ->
                if (stopped) return@synthesize false
                val bytes = ByteArray(pcm.size * 2)
                for (i in pcm.indices) {
                    bytes[2 * i] = (pcm[i].toInt() and 0xFF).toByte()
                    bytes[2 * i + 1] = ((pcm[i].toInt() shr 8) and 0xFF).toByte()
                }
                var off = 0
                while (off < bytes.size) {
                    if (stopped) return@synthesize false
                    val n = minOf(maxBuf, bytes.size - off)
                    if (callback.audioAvailable(bytes, off, n) != TextToSpeech.SUCCESS) return@synthesize false
                    off += n
                }
                true
            }
            if (!stopped) callback.done()
        } catch (t: Throwable) {
            callback.error()
        }
    }
}
