package com.nara.tts

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import kotlin.math.abs

object NaraRuntime {
    @Volatile private var fe: Frontend? = null
    @Volatile private var eng: NaraEngine? = null

    fun frontend(ctx: Context): Frontend = fe ?: synchronized(this) {
        fe ?: Frontend(readAsset(ctx, "lexicon_exceptions.tsv"), readAsset(ctx, "mined_rules.tsv")).also { fe = it }
    }

    fun engine(ctx: Context): NaraEngine = eng ?: synchronized(this) {
        eng ?: NaraEngine(ctx.applicationContext).also { eng = it }
    }

    /** Loads the English dictionary (if downloaded) into the frontend. */
    fun ensureEnglish(ctx: Context) {
        val fe = frontend(ctx)
        if (fe.english != null || !EnglishDict.isInstalled(ctx)) return
        synchronized(this) {
            if (fe.english == null) {
                try {
                    fe.english = EnglishG2P(EnglishDict.load(ctx))
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun readAsset(ctx: Context, name: String): String =
        ctx.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }
}

/** Runs the Nara Mini v1 ONNX encoder + decoder (same pipeline as synthesize.py). */
class NaraEngine(private val ctx: Context) {
    companion object {
        const val SAMPLE_RATE = 24000
        private const val CHUNK_LIMIT = 100
        private const val MAX_TOKENS = 508
    }

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private var voice: String? = null
    private var enc: OrtSession? = null
    private var dec: OrtSession? = null
    private var vocab: Map<String, Int> = emptyMap()
    private var centers: DoubleArray = DoubleArray(0)
    private var styles: List<FloatArray> = emptyList()
    private var styleShape: LongArray = LongArray(0)

    /** Short human-readable trace of the last synthesize() call (shown in the test screen). */
    @Volatile var lastDebug: String = ""
    private var note: String = ""
    private fun fail(msg: String): FloatArray? { note = msg; return null }

    @Synchronized
    fun ensureLoaded(id: String) {
        if (voice == id && enc != null && dec != null) return
        close()
        val dir = VoiceStore.dir(ctx, id)
        val meta = JSONObject(File(dir, "voice.json").readText(Charsets.UTF_8))

        val v = meta.getJSONObject("vocab")
        val vm = HashMap<String, Int>()
        for (k in v.keys()) vm[k] = v.getInt(k)
        vocab = vm

        val c = meta.getJSONArray("centers")
        centers = DoubleArray(c.length()) { c.getDouble(it) }

        val s = meta.getJSONArray("styles")
        val list = ArrayList<FloatArray>()
        for (i in 0 until s.length()) {
            val flat = ArrayList<Float>()
            flatten(s.get(i), flat)
            list.add(flat.toFloatArray())
        }
        styles = list
        val dims = ArrayList<Long>()
        dims.add(1L)
        dims.addAll(shapeOf(s.get(0)))
        styleShape = dims.toLongArray()

        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
        opts.setInterOpNumThreads(1)
        enc = env.createSession(File(dir, "encoder.onnx").absolutePath, opts)
        dec = env.createSession(File(dir, "decoder.onnx").absolutePath, opts)
        voice = id
    }

    @Synchronized
    fun close() {
        try { enc?.close() } catch (_: Exception) {}
        try { dec?.close() } catch (_: Exception) {}
        enc = null; dec = null; voice = null
    }

    private fun flatten(a: Any, out: MutableList<Float>) {
        if (a is JSONArray) {
            for (i in 0 until a.length()) flatten(a.get(i), out)
        } else {
            out.add((a as Number).toFloat())
        }
    }

    private fun shapeOf(a: Any): List<Long> {
        if (a !is JSONArray) return emptyList()
        val r = ArrayList<Long>()
        r.add(a.length().toLong())
        if (a.length() > 0) r.addAll(shapeOf(a.get(0)))
        return r
    }

    /**
     * Synthesises [text]; every finished piece is passed to [onAudio] as 16-bit PCM at 24 kHz.
     * Return false from [onAudio] to stop early.
     */
    @Synchronized
    fun synthesize(id: String, text: String, onAudio: (ShortArray) -> Boolean) {
        ensureLoaded(id)
        NaraRuntime.ensureEnglish(ctx)
        val dbg = StringBuilder()
        lastDebug = ""
        val fe = NaraRuntime.frontend(ctx)
        val spoken = fe.verbalize(text)
        var first = true
        var idx = 0
        for (piece in fe.splitSpeech(spoken, CHUNK_LIMIT)) {
            idx++
            val symbols = fe.phonemes(piece)
            val tokens = ArrayList<Long>()
            for (ch in symbols) vocab[ch.toString()]?.let { tokens.add(it.toLong()) }
            dbg.append("#").append(idx).append(" sym=\"").append(symbols.take(70)).append("\" tokens=").append(tokens.size)
            if (tokens.isEmpty()) { dbg.append(" SKIP(no tokens)\n"); lastDebug = dbg.toString(); continue }
            while (tokens.size > MAX_TOKENS) tokens.removeAt(tokens.size - 1)

            var best = 0
            var bestDist = Double.MAX_VALUE
            for (i in centers.indices) {
                val dist = abs(centers[i] - tokens.size)
                if (dist < bestDist) { bestDist = dist; best = i }
            }
            note = ""
            val samples = runPiece(tokens, styles[best.coerceAtMost(styles.size - 1)])
            if (samples == null) { dbg.append(" SKIP(").append(note).append(")\n"); lastDebug = dbg.toString(); continue }
            dbg.append(" audio=").append(samples.size).append("\n")
            lastDebug = dbg.toString()
            if (!first && !onAudio(ShortArray(4800))) return
            first = false
            if (!onAudio(toPcm(samples))) return
        }
    }

    private fun runPiece(tokens: List<Long>, style: FloatArray): FloatArray? {
        val encoder = enc ?: return fail("no encoder")
        val decoder = dec ?: return fail("no decoder")
        val ids = LongArray(tokens.size + 2)
        for (i in tokens.indices) ids[i + 1] = tokens[i]

        var durations = IntArray(0)
        var prosody = FloatArray(0)
        var textEnc = FloatArray(0)
        var pShape = LongArray(0)
        var tShape = LongArray(0)
        OnnxTensor.createTensor(env, LongBuffer.wrap(ids), longArrayOf(1, ids.size.toLong())).use { tokT ->
            OnnxTensor.createTensor(env, FloatBuffer.wrap(style), styleShape).use { styT ->
                encoder.run(
                    mapOf("tokens" to tokT, "style" to styT),
                    setOf("durations", "prosody", "text")
                ).use { res ->
                    val dT = res.get("durations").get() as OnnxTensor
                    val pT = res.get("prosody").get() as OnnxTensor
                    val tT = res.get("text").get() as OnnxTensor
                    durations = readInts(dT)
                    prosody = readFloats(pT)
                    textEnc = readFloats(tT)
                    pShape = (pT.info as TensorInfo).shape
                    tShape = (tT.info as TensorInfo).shape
                }
            }
        }
        val n = durations.size
        if (pShape.size != 3 || tShape.size != 3) return fail("shapes p=" + pShape.toList() + " t=" + tShape.toList())
        val cP = pShape[1].toInt()
        val cT = tShape[1].toInt()
        if (pShape[2].toInt() != n || tShape[2].toInt() != n) {
            return fail("len mismatch dur=" + n + " p=" + pShape.toList() + " t=" + tShape.toList())
        }
        var total = 0
        for (d in durations) { if (d < 0) return fail("negative duration"); total += d }
        if (total < 1 || total > 20000) return fail("total frames=" + total)

        val pr = expand(prosody, durations, cP, total)
        val tx = expand(textEnc, durations, cT, total)
        val shapeP = longArrayOf(1, cP.toLong(), total.toLong())
        val shapeT = longArrayOf(1, cT.toLong(), total.toLong())

        var audio = FloatArray(0)
        OnnxTensor.createTensor(env, FloatBuffer.wrap(pr), shapeP).use { prT ->
            OnnxTensor.createTensor(env, FloatBuffer.wrap(tx), shapeT).use { txT ->
                OnnxTensor.createTensor(env, FloatBuffer.wrap(style), styleShape).use { styT ->
                    decoder.run(mapOf("prosody" to prT, "text" to txT, "style" to styT)).use { res ->
                        audio = readFloats(res.get(0) as OnnxTensor)
                    }
                }
            }
        }
        if (audio.size < 2400) return fail("audio too short=" + audio.size)
        for (x in audio) if (x.isNaN() || x.isInfinite()) return fail("NaN audio")
        return audio
    }

    private fun readFloats(t: OnnxTensor): FloatArray {
        val b = t.floatBuffer
        val a = FloatArray(b.remaining())
        b.get(a)
        return a
    }

    private fun readInts(t: OnnxTensor): IntArray {
        return when ((t.info as TensorInfo).type.name) {
            "INT64" -> { val b = t.longBuffer; IntArray(b.remaining()) { b.get().toInt() } }
            "INT32" -> { val b = t.intBuffer; IntArray(b.remaining()) { b.get() } }
            else -> { val b = t.floatBuffer; IntArray(b.remaining()) { Math.round(b.get()) } }
        }
    }

    /** np.repeat(x, durations, axis=2) for x of shape [1, C, N]. */
    private fun expand(src: FloatArray, d: IntArray, c: Int, total: Int): FloatArray {
        val n = d.size
        val out = FloatArray(c * total)
        for (ch in 0 until c) {
            var o = ch * total
            val base = ch * n
            for (i in 0 until n) {
                val v = src[base + i]
                for (r in 0 until d[i]) out[o++] = v
            }
        }
        return out
    }

    /** Peak-normalise each piece (the raw model output is quiet) and convert to 16-bit PCM. */
    private fun toPcm(x: FloatArray): ShortArray {
        var peak = 0f
        for (v in x) { val a = abs(v); if (a > peak) peak = a }
        val gain = if (peak > 0.01f) minOf(3f, 0.85f / peak) else 1f
        return ShortArray(x.size) {
            val s = (x[it] * gain).coerceIn(-1f, 1f)
            (s * 32767f).toInt().toShort()
        }
    }
}
