package com.nara.tts

/**
 * English word -> Kokoro/misaki phoneme string.
 * 1) dictionary (misaki us_gold + us_silver), 2) plural/past/-ing stemming,
 * 3) acronym spelling, 4) simple letter-to-sound rules for unknown words.
 */
class EnglishG2P(private val dict: Map<String, String>) {

    fun phonemes(run: String): String {
        val words = ArrayList<String>()
        for (m in WORD.findAll(run)) {
            val p = word(m.value)
            if (p.isNotEmpty()) words.add(p)
        }
        return words.joinToString(" ")
    }

    private fun lookup(w: String): String? {
        dict[w]?.let { return it }
        val lo = w.lowercase()
        dict[lo]?.let { return it }
        if (lo.length > 1) dict[lo.substring(0, 1).uppercase() + lo.substring(1)]?.let { return it }
        return null
    }

    private fun lastChar(p: String): Char = if (p.isEmpty()) ' ' else p[p.length - 1]

    private fun sSuffix(p: String): String {
        val c = lastChar(p)
        return when {
            "s\u0292z\u0283\u02A7\u02A4".indexOf(c) >= 0 -> "\u026Az"
            "ptkf\u03B8".indexOf(c) >= 0 -> "s"
            else -> "z"
        }
    }

    private fun dSuffix(p: String): String {
        val c = lastChar(p)
        return when {
            c == 't' || c == 'd' -> "\u026Ad"
            "pkfs\u0283\u02A7\u03B8".indexOf(c) >= 0 -> "t"
            else -> "d"
        }
    }

    private fun inflect(lo: String): String? {
        if (lo.endsWith("'s") && lo.length > 3) {
            val b = lookup(lo.substring(0, lo.length - 2))
            if (b != null) return b + sSuffix(b)
        }
        if (lo.endsWith("s") && lo.length > 2) {
            val stems = ArrayList<String>()
            if (lo.endsWith("ies") && lo.length > 4) stems.add(lo.substring(0, lo.length - 3) + "y")
            if (lo.endsWith("es") && lo.length > 3) stems.add(lo.substring(0, lo.length - 2))
            stems.add(lo.substring(0, lo.length - 1))
            for (st in stems) {
                val b = lookup(st)
                if (b != null) return b + sSuffix(b)
            }
        }
        if (lo.endsWith("ed") && lo.length > 3) {
            val stems = ArrayList<String>()
            stems.add(lo.substring(0, lo.length - 2))
            stems.add(lo.substring(0, lo.length - 1))
            if (lo.length > 4 && lo[lo.length - 3] == lo[lo.length - 4]) stems.add(lo.substring(0, lo.length - 3))
            for (st in stems) {
                val b = lookup(st)
                if (b != null) return b + dSuffix(b)
            }
        }
        if (lo.endsWith("ing") && lo.length > 4) {
            val base = lo.substring(0, lo.length - 3)
            val stems = ArrayList<String>()
            stems.add(base)
            stems.add(base + "e")
            if (base.length > 1 && base[base.length - 1] == base[base.length - 2]) stems.add(base.substring(0, base.length - 1))
            for (st in stems) {
                val b = lookup(st)
                if (b != null) return b + "\u026A\u014B"
            }
        }
        return null
    }

    private fun word(w: String): String {
        lookup(w)?.let { return it }
        val lo = w.lowercase()
        inflect(lo)?.let { return it }
        if (w.length in 2..6 && w.all { it in 'A'..'Z' }) return spell(w)
        val parts = ArrayList<String>()
        for (m in CAMEL.findAll(w)) parts.add(m.value)
        if (parts.size > 1) {
            return parts.joinToString(" ") { part ->
                lookup(part) ?: inflect(part.lowercase())
                    ?: (if (part.length in 2..6 && part.all { it in 'A'..'Z' }) spell(part) else rules(part.lowercase()))
            }
        }
        return rules(lo)
    }

    private fun spell(w: String): String = w.map { LETTERS[it] ?: "" }.filter { it.isNotEmpty() }.joinToString(" ")

    /** Very small letter-to-sound fallback for words that are not in the dictionary. */
    private fun rules(wIn: String): String {
        val w = wIn.replace("'", "")
        val n = w.length
        if (n == 0) return ""
        val out = StringBuilder()
        var stressed = false
        fun v(p: String) {
            if (!stressed) { out.append("\u02C8"); stressed = true }
            out.append(p)
        }
        fun isV(c: Char) = "aeiouy".indexOf(c) >= 0
        var i = 0
        while (i < n) {
            val c = w[i]
            val r = w.substring(i)
            if (r.startsWith("tch")) { out.append("\u02A7"); i += 3; continue }
            if (r.startsWith("dge")) { out.append("\u02A4"); i += 3; continue }
            if (r.startsWith("igh")) { v("I"); i += 3; continue }
            if (r.startsWith("th")) { out.append("\u03B8"); i += 2; continue }
            if (r.startsWith("sh")) { out.append("\u0283"); i += 2; continue }
            if (r.startsWith("ch")) { out.append("\u02A7"); i += 2; continue }
            if (r.startsWith("ph")) { out.append("f"); i += 2; continue }
            if (r.startsWith("wh")) { out.append("w"); i += 2; continue }
            if (r.startsWith("ck")) { out.append("k"); i += 2; continue }
            if (r.startsWith("ng")) { out.append("\u014B"); i += 2; continue }
            if (r.startsWith("qu")) { out.append("kw"); i += 2; continue }
            if (i == 0 && (r.startsWith("kn") || r.startsWith("gn"))) { out.append("n"); i += 2; continue }
            if (i == 0 && r.startsWith("wr")) { out.append("\u0279"); i += 2; continue }
            if (r.startsWith("ee") || r.startsWith("ea") || r.startsWith("ie")) { v("i"); i += 2; continue }
            if (r.startsWith("oo")) { v("u"); i += 2; continue }
            if (r.startsWith("ai") || r.startsWith("ay")) { v("A"); i += 2; continue }
            if (r.startsWith("oa")) { v("O"); i += 2; continue }
            if (r.startsWith("ow")) { v(if (i + 2 >= n) "O" else "W"); i += 2; continue }
            if (r.startsWith("ou")) { v("W"); i += 2; continue }
            if (r.startsWith("oi") || r.startsWith("oy")) { v("Y"); i += 2; continue }
            if (r.startsWith("au") || r.startsWith("aw")) { v("\u0254"); i += 2; continue }
            if (r.startsWith("ew") || r.startsWith("ue")) { v("u"); i += 2; continue }
            if (r.startsWith("ar")) { v("\u0251\u0279"); i += 2; continue }
            if (r.startsWith("or")) { v("\u0254\u0279"); i += 2; continue }
            if (r.startsWith("er") || r.startsWith("ir") || r.startsWith("ur")) { v("\u025C\u0279"); i += 2; continue }
            if (c == 'e' && i == n - 1 && i > 0 && stressed) { i++; continue } // silent final e
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                val magic = i + 2 == n - 1 && w[i + 2] == 'e' && !isV(w[i + 1])
                val p = when (c) {
                    'a' -> if (magic) "A" else "\u00E6"
                    'e' -> if (magic) "i" else "\u025B"
                    'i' -> if (magic) "I" else "\u026A"
                    'o' -> if (magic) "O" else "\u0251"
                    else -> if (magic) "u" else "\u028C"
                }
                v(p); i++; continue
            }
            if (c == 'y') {
                if (i == 0) out.append("j") else if (i == n - 1) v(if (n <= 3) "I" else "i") else v("\u026A")
                i++; continue
            }
            if (i + 1 < n && w[i + 1] == c) { i++; continue } // double consonant
            when (c) {
                'c' -> out.append(if (i + 1 < n && "eiy".indexOf(w[i + 1]) >= 0) "s" else "k")
                'g' -> out.append(if (i + 1 < n && "eiy".indexOf(w[i + 1]) >= 0) "\u02A4" else "\u0261")
                'x' -> out.append("ks")
                'j' -> out.append("\u02A4")
                'q' -> out.append("k")
                'r' -> out.append("\u0279")
                's' -> out.append(if (i > 0 && i < n - 1 && isV(w[i - 1]) && isV(w[i + 1])) "z" else "s")
                else -> if ("bdfhklmnpstvwz".indexOf(c) >= 0) out.append(c)
            }
            i++
        }
        return out.toString()
    }

    companion object {
        private val WORD = Regex("[A-Za-z]+(?:'[A-Za-z]+)*")
        private val CAMEL = Regex("[A-Z]+(?![a-z])|[A-Z]?[a-z]+")
        private val LETTERS: Map<Char, String> = mapOf(
            'A' to "\u02C8A", 'B' to "b\u02C8i", 'C' to "s\u02C8i", 'D' to "d\u02C8i", 'E' to "\u02C8i",
            'F' to "\u02C8\u025Bf", 'G' to "\u02A4\u02C8i", 'H' to "\u02C8A\u02A7", 'I' to "\u02C8I",
            'J' to "\u02A4\u02C8A", 'K' to "k\u02C8A", 'L' to "\u02C8\u025Bl", 'M' to "\u02C8\u025Bm",
            'N' to "\u02C8\u025Bn", 'O' to "\u02C8O", 'P' to "p\u02C8i", 'Q' to "kj\u02C8u",
            'R' to "\u02C8\u0251\u0279", 'S' to "\u02C8\u025Bs", 'T' to "t\u02C8i", 'U' to "j\u02C8u",
            'V' to "v\u02C8i", 'W' to "d\u02C8\u028Cb\u0259lju", 'X' to "\u02C8\u025Bks",
            'Y' to "w\u02C8I", 'Z' to "z\u02C8i"
        )
    }
}
