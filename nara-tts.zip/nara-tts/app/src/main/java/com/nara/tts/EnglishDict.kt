package com.nara.tts

import android.content.Context
import org.json.JSONObject
import java.io.File

/** misaki US English pronunciation dictionary (Apache-2.0), downloaded once. */
object EnglishDict {
    private val FILES = listOf("us_silver.json", "us_gold.json") // gold overrides silver
    private const val BASE = "https://huggingface.co/datasets/hexgrad/misaki/resolve/main/"

    private fun dir(ctx: Context) = File(ctx.filesDir, "en")

    fun isInstalled(ctx: Context): Boolean =
        FILES.all { File(dir(ctx), it).let { f -> f.exists() && f.length() > 0 } }

    fun download(ctx: Context, onProgress: (String) -> Unit) {
        val d = dir(ctx)
        d.mkdirs()
        for (name in FILES) {
            val target = File(d, name)
            if (target.exists() && target.length() > 0) continue
            val part = File(d, "$name.part")
            VoiceStore.downloadFile(java.net.URL(BASE + name), part) { mb -> onProgress("$name  $mb MB") }
            if (!part.renameTo(target)) throw IllegalStateException("Cannot save $name")
        }
    }

    fun load(ctx: Context): Map<String, String> {
        val map = HashMap<String, String>(400000)
        for (name in FILES) {
            val text = File(dir(ctx), name).readText(Charsets.UTF_8)
            val json = JSONObject(text)
            val keys = json.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = json.opt(k)
                var ps: String? = null
                if (v is String) {
                    ps = v
                } else if (v is JSONObject) {
                    val def = v.opt("DEFAULT")
                    if (def is String) {
                        ps = def
                    } else {
                        val it2 = v.keys()
                        while (it2.hasNext() && ps == null) {
                            val x = v.opt(it2.next())
                            if (x is String) ps = x
                        }
                    }
                }
                if (ps != null && ps.isNotEmpty()) map[k] = ps
            }
        }
        return map
    }
}
