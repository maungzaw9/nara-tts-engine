package com.nara.tts

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object VoiceStore {
    val VOICES = listOf(
        "shoon" to "Shoon",
        "thazin" to "Thazin",
        "ko-banyar" to "Ko Banyar",
        "htet-myat" to "Htet Myat"
    )
    private val FILES = listOf("voice.json", "encoder.onnx", "decoder.onnx")
    private const val BASE = "https://huggingface.co/YeeNyunn/nara-mini-v1/resolve/main/onnx/"

    fun dir(ctx: Context, id: String) = File(ctx.filesDir, "voices/$id")

    fun isInstalled(ctx: Context, id: String): Boolean =
        FILES.all { File(dir(ctx, id), it).let { f -> f.exists() && f.length() > 0 } }

    fun installed(ctx: Context): List<String> = VOICES.map { it.first }.filter { isInstalled(ctx, it) }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("nara", Context.MODE_PRIVATE)

    fun currentVoice(ctx: Context): String? {
        val inst = installed(ctx)
        val saved = prefs(ctx).getString("voice", null)
        return if (saved != null && saved in inst) saved else inst.firstOrNull()
    }

    fun setCurrentVoice(ctx: Context, id: String) {
        prefs(ctx).edit().putString("voice", id).apply()
    }

    fun displayName(id: String) = VOICES.firstOrNull { it.first == id }?.second ?: id

    /** Downloads the three files of a voice (resumable). Blocking; call from a worker thread. */
    fun download(ctx: Context, id: String, onProgress: (String) -> Unit) {
        val d = dir(ctx, id)
        d.mkdirs()
        for (name in FILES) {
            val target = File(d, name)
            if (target.exists() && target.length() > 0) continue
            val part = File(d, "$name.part")
            downloadFile(URL("$BASE$id/$name"), part) { mb -> onProgress("$name  $mb MB") }
            if (!part.renameTo(target)) throw IllegalStateException("Cannot save $name")
        }
    }

    internal fun downloadFile(url: URL, part: File, onMb: (Long) -> Unit) {
        val existing = if (part.exists()) part.length() else 0L
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 30000
        conn.readTimeout = 60000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "NaraTTS-Android")
        if (existing > 0) conn.setRequestProperty("Range", "bytes=$existing-")
        try {
            val code = conn.responseCode
            if (code == 416) return // .part is already complete
            if (code != 200 && code != 206) throw IllegalStateException("HTTP $code")
            val append = code == 206 && existing > 0
            var expected = -1L
            if (code == 206) {
                val cr = conn.getHeaderField("Content-Range")
                if (cr != null && cr.indexOf('/') > 0) expected = cr.substring(cr.indexOf('/') + 1).trim().toLongOrNull() ?: -1L
            } else {
                expected = conn.contentLengthLong
            }
            var done = if (append) existing else 0L
            var lastMb = -1L
            FileOutputStream(part, append).use { out ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val mb = done / (1024 * 1024)
                        if (mb != lastMb) { lastMb = mb; onMb(mb) }
                    }
                }
            }
            if (expected > 0 && done != expected) {
                throw java.io.IOException("incomplete: " + done + " of " + expected + " bytes")
            }
        } finally {
            conn.disconnect()
        }
    }
}
