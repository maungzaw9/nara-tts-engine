package com.nara.tts

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var voiceList: LinearLayout
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var speakBtn: Button
    @Volatile private var speaking = false
    @Volatile private var track: AudioTrack? = null
    private val downloading = HashSet<String>()
    private lateinit var enBtn: Button
    @Volatile private var enDownloading = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))

        val title = TextView(this)
        title.text = "Nara TTS engine"
        title.textSize = 24f
        title.setTypeface(null, Typeface.BOLD)
        root.addView(title)

        val help = TextView(this)
        help.text = "1. Download a voice (needs internet once, about 181 MB).\n" +
            "2. Open Android text-to-speech settings and choose \"Nara TTS\" as the engine.\n" +
            "3. Language: Burmese. Then Select to Speak will read Burmese text offline."
        help.setPadding(0, dp(8), 0, dp(8))
        root.addView(help)

        voiceList = LinearLayout(this)
        voiceList.orientation = LinearLayout.VERTICAL
        root.addView(voiceList)

        enBtn = Button(this)
        root.addView(enBtn)

        status = TextView(this)
        status.setPadding(0, dp(8), 0, dp(8))
        root.addView(status)

        val settingsBtn = Button(this)
        settingsBtn.text = "Open Android TTS settings"
        settingsBtn.setOnClickListener {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        root.addView(settingsBtn)

        input = EditText(this)
        input.setText(Tables.SAMPLE_TEXT)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.gravity = Gravity.TOP
        input.minLines = 3
        root.addView(input)

        speakBtn = Button(this)
        speakBtn.text = "Test speak"
        speakBtn.setOnClickListener { if (speaking) stopSpeaking() else speak() }
        root.addView(speakBtn)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        refresh()
    }

    private fun refresh() {
        voiceList.removeAllViews()
        val current = VoiceStore.currentVoice(this)
        for ((id, name) in VoiceStore.VOICES) {
            val b = Button(this)
            val installed = VoiceStore.isInstalled(this, id)
            b.text = when {
                id in downloading -> "$name - downloading..."
                installed && id == current -> "$name - installed (in use)"
                installed -> "$name - installed (tap to use)"
                else -> "$name - download (181 MB)"
            }
            b.isEnabled = id !in downloading
            b.setOnClickListener {
                if (installed) {
                    VoiceStore.setCurrentVoice(this, id)
                    refresh()
                } else {
                    startDownload(id)
                }
            }
            voiceList.addView(b)
        }
        val enInstalled = EnglishDict.isInstalled(this)
        enBtn.text = when {
            enDownloading -> "English words - downloading..."
            enInstalled -> "English words - installed"
            else -> "English words - download dictionary (6 MB)"
        }
        enBtn.isEnabled = !enDownloading && !enInstalled
        enBtn.setOnClickListener { startEnglishDownload() }
    }

    private fun startEnglishDownload() {
        enDownloading = true
        refresh()
        Thread {
            try {
                EnglishDict.download(this) { msg -> runOnUiThread { status.text = "English: $msg" } }
                runOnUiThread { status.text = "English dictionary: done" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Download failed: ${e.message}. Tap again to resume." }
            } finally {
                enDownloading = false
                runOnUiThread { refresh() }
            }
        }.start()
    }

    private fun startDownload(id: String) {
        downloading.add(id)
        refresh()
        Thread {
            try {
                VoiceStore.download(this, id) { msg -> runOnUiThread { status.text = "${VoiceStore.displayName(id)}: $msg" } }
                runOnUiThread { status.text = "${VoiceStore.displayName(id)}: done" }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Download failed: ${e.message}. Tap the voice again to resume." }
            } finally {
                downloading.remove(id)
                runOnUiThread { refresh() }
            }
        }.start()
    }

    private fun speak() {
        val voice = VoiceStore.currentVoice(this)
        if (voice == null) {
            Toast.makeText(this, "Download a voice first", Toast.LENGTH_SHORT).show()
            return
        }
        val text = input.text.toString()
        speaking = true
        speakBtn.text = "Stop"
        status.text = "Loading model..."
        Thread {
            var at: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    NaraEngine.SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val atr = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(NaraEngine.SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(minBuf * 4)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                at = atr
                track = atr
                atr.play()
                val started = System.currentTimeMillis()
                var firstAudio = true
                var frames = 0L
                NaraRuntime.engine(this).synthesize(voice, text) { pcm ->
                    if (!speaking) return@synthesize false
                    if (firstAudio) {
                        firstAudio = false
                        val ms = System.currentTimeMillis() - started
                        runOnUiThread { status.text = "Speaking (first audio after $ms ms)" }
                    }
                    atr.write(pcm, 0, pcm.size)
                    frames += pcm.size
                    true
                }
                // let the buffered audio finish playing before releasing the track
                var waited = 0
                while (speaking && atr.playbackHeadPosition < frames && waited < 600) {
                    Thread.sleep(50)
                    waited++
                }
                if (speaking) atr.stop()
                val dbg = NaraRuntime.engine(this).lastDebug
                runOnUiThread { if (speaking) status.text = "Finished. samples=" + frames + "\n" + dbg }
            } catch (t: Throwable) {
                val dbg2 = try { NaraRuntime.engine(this).lastDebug } catch (_: Throwable) { "" }
                runOnUiThread { status.text = "Error: ${t.javaClass.simpleName}: ${t.message}\n" + dbg2 }
            } finally {
                try { at?.release() } catch (_: Exception) {}
                track = null
                speaking = false
                runOnUiThread { speakBtn.text = "Test speak" }
            }
        }.start()
    }

    private fun stopSpeaking() {
        speaking = false
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        speaking = false
        super.onDestroy()
    }
}
