package com.nara.tts

// GENERATED from the Nara Mini v1 Python frontend. Do not edit by hand.
internal object Tables {
    val ONSET: Map<Char, String> = mapOf(
        '\u1000' to "k",
        '\u1001' to "k\u02B0",
        '\u1002' to "g",
        '\u1003' to "g",
        '\u1004' to "\u014B",
        '\u1005' to "s",
        '\u1006' to "s\u02B0",
        '\u1007' to "z",
        '\u1008' to "z",
        '\u100A' to "\u0272",
        '\u1009' to "\u0272",
        '\u100B' to "t",
        '\u100C' to "t\u02B0",
        '\u100D' to "d",
        '\u100E' to "d",
        '\u100F' to "n",
        '\u1010' to "t",
        '\u1011' to "t\u02B0",
        '\u1012' to "d",
        '\u1013' to "d",
        '\u1014' to "n",
        '\u1015' to "p",
        '\u1016' to "p\u02B0",
        '\u1017' to "b",
        '\u1018' to "b",
        '\u1019' to "m",
        '\u101A' to "j",
        '\u101B' to "j",
        '\u101C' to "l",
        '\u101D' to "w",
        '\u101E' to "\u03B8",
        '\u101F' to "h",
        '\u1020' to "l",
        '\u1021' to "\u0294"
    )
    val VELAR_PAL: Map<String, String> = mapOf(
        "k" to "t\u0255",
        "k\u02B0" to "t\u0255\u02B0",
        "g" to "d\u0291"
    )
    val ASPIRATE: Map<String, String> = mapOf(
        "m" to "m\u0325",
        "n" to "n\u0325",
        "\u0272" to "\u0272\u0325",
        "\u014B" to "\u014B\u030A",
        "l" to "l\u0325",
        "j" to "\u0283",
        "w" to "w\u0325"
    )
    val VOICE_MAP: Map<String, String> = mapOf(
        "k" to "g",
        "k\u02B0" to "g",
        "s" to "z",
        "s\u02B0" to "z",
        "t" to "d",
        "t\u02B0" to "d",
        "p" to "b",
        "p\u02B0" to "b",
        "t\u0255" to "d\u0291",
        "t\u0255\u02B0" to "d\u0291",
        "\u03B8" to "\u00F0"
    )
    val INDEP_SYL: Map<Char, Triple<String, String, String>> = mapOf(
        '\u1023' to Triple("\u0294", "i", "\u02C0"),
        '\u1024' to Triple("\u0294", "i", "\u02E7"),
        '\u1025' to Triple("\u0294", "u", "\u02C0"),
        '\u1026' to Triple("\u0294", "u", "\u02E7"),
        '\u1027' to Triple("\u0294", "e", "\u02E7"),
        '\u1029' to Triple("\u0294", "\u0254", "\u02E5"),
        '\u102A' to Triple("\u0294", "\u0254", "\u02E7")
    )
    val V: Map<String, Pair<String, String>> = mapOf(
        "" to Pair("a", "\u02C0"),
        "\u102C" to Pair("a", "\u02E7"),
        "\u102D" to Pair("i", "\u02C0"),
        "\u102E" to Pair("i", "\u02E7"),
        "\u102F" to Pair("u", "\u02C0"),
        "\u1030" to Pair("u", "\u02E7"),
        "\u1031" to Pair("e", "\u02E7"),
        "\u1032" to Pair("\u025B", "\u02E5"),
        "\u1031\u102C" to Pair("\u0254", "\u02E5"),
        "\u102D\u102F" to Pair("o", "\u02E7")
    )
    val RHYME_CLOSED: Map<Pair<String, String>, String> = mapOf(
        Pair("", "F_K") to "\u025B\u0294",
        Pair("", "F_S") to "\u026A\u0294",
        Pair("", "F_T") to "a\u0294",
        Pair("\u102D", "F_T") to "e\u026A\u0294",
        Pair("\u102F", "F_T") to "o\u028A\u0294",
        Pair("\u103D", "F_T") to "\u028A\u0294",
        Pair("\u102D\u102F", "F_K") to "a\u026A\u0294",
        Pair("\u1031\u102C", "F_K") to "a\u028A\u0294",
        Pair("\u103D", "F_S") to "\u026A\u0294",
        Pair("\u102D", "F_S") to "\u026A\u0294",
        Pair("\u102F", "F_S") to "\u028A\u0294",
        Pair("", "F_NG") to "\u026A\u0274",
        Pair("", "F_NY") to "\u026A\u0274",
        Pair("", "F_N") to "a\u0274",
        Pair("\u102C", "F_T") to "a\u0294",
        Pair("\u102C", "F_N") to "a\u0274",
        Pair("\u1031", "F_T") to "\u026A\u0294",
        Pair("\u102F", "F_K") to "o\u028A\u0294",
        Pair("\u102C", "F_NY") to "\u026A\u0274",
        Pair("\u102D", "F_K") to "e\u026A\u0294",
        Pair("\u102D", "F_NG") to "e\u026A\u0274",
        Pair("\u102D\u102F", "F_N") to "a\u026A\u0274",
        Pair("\u102D", "F_N") to "e\u026A\u0274",
        Pair("\u102F", "F_N") to "o\u028A\u0274",
        Pair("\u103D", "F_N") to "\u028A\u0274",
        Pair("\u102D\u102F", "F_NG") to "a\u026A\u0274",
        Pair("\u1031\u102C", "F_NG") to "a\u028A\u0274"
    )
    const val F_K = "\u1000\u1002"
    const val F_S = "\u1005\u1007"
    const val F_T = "\u1010\u1012\u1015\u1017\u100B\u100D\u101E"
    const val F_N = "\u1014\u1019\u100F"
    const val F_NG = "\u1004"
    const val F_NY = "\u1009"
    val CLASSIFIERS: Set<String> = setOf(
        "\u1000\u1031\u102C\u1004\u103A",
        "\u1000\u103C\u102D\u1019\u103A",
        "\u1001\u1014\u103A\u1038",
        "\u1001\u102B",
        "\u1001\u102F",
        "\u1001\u1031\u102B\u1000\u103A",
        "\u1001\u103B\u1000\u103A",
        "\u1001\u103B\u1031\u102C\u1004\u103A",
        "\u1001\u103B\u1031\u102C\u1004\u103A\u1038",
        "\u1001\u103D\u1014\u103A\u1038",
        "\u1005\u102E\u1038",
        "\u1005\u102F",
        "\u1005\u1031\u102C\u1004\u103A",
        "\u1006\u1030",
        "\u1010\u1014\u103A\u1038",
        "\u1011\u100A\u103A",
        "\u1014\u102C\u101B\u102E",
        "\u1014\u1031\u1037",
        "\u1014\u103E\u1005\u103A",
        "\u1015\u1004\u103A",
        "\u1015\u1010\u103A",
        "\u1015\u102B\u1038",
        "\u1015\u102F\u1012\u103A",
        "\u1016\u1000\u103A",
        "\u1019\u102D\u1014\u1005\u103A",
        "\u1019\u103B\u102D\u102F\u1038",
        "\u101A\u1031\u102C\u1000\u103A",
        "\u101B\u1000\u103A",
        "\u101B\u103D\u1000\u103A",
        "\u101C",
        "\u101C\u1000\u103A",
        "\u101C\u102F\u1036\u1038",
        "\u101C\u103E\u1019\u103A\u1038",
        "\u101D\u102D\u102F\u1004\u103A\u1038",
        "\u101E\u103B\u103E\u1030\u1038",
        "\u1021\u102F\u1015\u103A",
        "\u1026\u1038"
    )
    val CHAR: Map<String, String> = mapOf(
        "k" to "k",
        "g" to "\u0261",
        "\u014B" to "\u014B",
        "s" to "s",
        "z" to "z",
        "\u0272" to "\u0272",
        "t" to "t",
        "d" to "d",
        "n" to "n",
        "p" to "p",
        "b" to "b",
        "m" to "m",
        "j" to "j",
        "r" to "r",
        "l" to "l",
        "w" to "w",
        "\u03B8" to "\u03B8",
        "\u00F0" to "\u00F0",
        "h" to "h",
        "\u0294" to "\u0294",
        "\u0283" to "\u0283",
        "f" to "f",
        "k\u02B0" to "k\u02B0",
        "s\u02B0" to "s\u02B0",
        "t\u02B0" to "t\u02B0",
        "p\u02B0" to "p\u02B0",
        "t\u0255" to "\u02A7",
        "t\u0255\u02B0" to "\u02A7\u02B0",
        "d\u0291" to "\u02A4",
        "m\u0325" to "\u02B0m",
        "n\u0325" to "\u02B0n",
        "\u0272\u0325" to "\u02B0\u0272",
        "\u014B\u030A" to "\u02B0\u014B",
        "l\u0325" to "\u02B0l",
        "w\u0325" to "w",
        "a" to "a",
        "i" to "i",
        "u" to "u",
        "e" to "e",
        "\u025B" to "\u025B",
        "\u0254" to "\u0254",
        "o" to "o",
        "\u0259" to "\u0259",
        "\u0274" to "\u0274",
        "\u0294fin" to "\u0294",
        "e\u026A" to "A",
        "o\u028A" to "O",
        "a\u026A" to "I",
        "a\u028A" to "W",
        "\u02E7" to "\u2192",
        "\u02E5" to "\u2197",
        "\u02C0" to "\u2193"
    )
    val RHYME_SPLIT: Map<String, List<String>> = mapOf(
        "\u026A\u0274" to listOf("i", "\u0274"),
        "a\u0274" to listOf("a", "\u0274"),
        "e\u026A\u0274" to listOf("A", "\u0274"),
        "o\u028A\u0274" to listOf("O", "\u0274"),
        "\u028A\u0274" to listOf("u", "\u0274"),
        "a\u026A\u0274" to listOf("I", "\u0274"),
        "a\u028A\u0274" to listOf("W", "\u0274"),
        "\u026A\u0294" to listOf("i", "\u0294"),
        "\u028A\u0294" to listOf("u", "\u0294"),
        "a\u0294" to listOf("a", "\u0294"),
        "\u025B\u0294" to listOf("\u025B", "\u0294"),
        "e\u026A\u0294" to listOf("A", "\u0294"),
        "o\u028A\u0294" to listOf("O", "\u0294"),
        "a\u026A\u0294" to listOf("I", "\u0294"),
        "a\u028A\u0294" to listOf("W", "\u0294"),
        "a" to listOf("a"),
        "i" to listOf("i"),
        "u" to listOf("u"),
        "e" to listOf("e"),
        "\u025B" to listOf("\u025B"),
        "\u0254" to listOf("\u0254"),
        "o" to listOf("o"),
        "\u0259" to listOf("\u0259")
    )
    val DIGITS: List<String> = listOf("\u101E\u102F\u100A", "\u1010\u1005\u103A", "\u1014\u103E\u1005\u103A", "\u101E\u102F\u1036\u1038", "\u101C\u1031\u1038", "\u1004\u102B\u1038", "\u1001\u103C\u1031\u102C\u1000\u103A", "\u1001\u102F\u1014\u1005\u103A", "\u101B\u103E\u1005\u103A", "\u1000\u102D\u102F\u1038")
    val PLACES: Map<Int, String> = mapOf(1 to "\u1006\u101A\u103A", 2 to "\u101B\u102C", 3 to "\u1011\u1031\u102C\u1004\u103A", 4 to "\u101E\u1031\u102C\u1004\u103A\u1038")
    val CREAKY: Map<String, String> = mapOf("\u1006\u101A\u103A" to "\u1006\u101A\u1037\u103A", "\u101B\u102C" to "\u101B\u102C\u1037", "\u1011\u1031\u102C\u1004\u103A" to "\u1011\u1031\u102C\u1004\u1037\u103A")
    const val S_DASAMA = " \u1012\u101E\u1019 "
    const val S_PERCENT = " \u101B\u102C\u1001\u102D\u102F\u1004\u103A\u1014\u103E\u102F\u1014\u103A\u1038"
    const val S_KYAT = " \u1000\u103B\u1015\u103A"
    const val S_LAKH = "\u101E\u102D\u1014\u103A\u1038"
    val NORM_PRE: List<Pair<String, String>> = listOf(
        Pair("\u200B", ""),
        Pair("\uFEFF", ""),
        Pair("\u1037\u103A", "\u103A\u1037"),
        Pair("\u101E\u103C\u1031\u102C\u103A", "\u102A"),
        Pair("\u101E\u103C", "\u1029"),
        Pair("\u1023", "\u1021\u102D"),
        Pair("\u1024", "\u1021\u102E"),
        Pair("\u1025", "\u1021\u102F"),
        Pair("\u1026", "\u1021\u1030"),
        Pair("\u1027", "\u1021\u1031"),
        Pair("\u1029", "\u1021\u1031\u102C"),
        Pair("\u102A", "\u1021\u1031\u102C\u103A"),
        Pair("\u1004\u103A\u1039", "\u1004\u103A")
    )
    val NORM_POST: List<Pair<String, String>> = listOf(
        Pair("\u103F", "\u101E\u103A\u101E"),
        Pair("\u104E\u1004\u103A\u1038", "\u101C\u100A\u103A\u1038\u1000\u1031\u102C\u1004\u103A\u1038"),
        Pair("\u104C", "\u1014\u103E\u102D\u102F\u1000\u103A"),
        Pair("\u104D", "\u101B\u103D\u1031\u1037"),
        Pair("\u104F", "\u1021\u102D")
    )
    const val SAMPLE_TEXT = "\u1019\u1004\u103A\u1039\u1002\u101C\u102C\u1015\u102B\u104B \u1012\u102E\u1014\u1031\u1037 \u101B\u102C\u101E\u102E\u1025\u1010\u102F \u1000\u1031\u102C\u1004\u103A\u1038\u1010\u101A\u103A\u104B"
}
