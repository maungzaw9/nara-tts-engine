package com.nara.tts

/**
 * Line-by-line Kotlin port of the Nara Mini v1 Python text frontend
 * (g2p_my.py, nara_frontend.py, char_map.py, my_numbers.py, split_speech()).
 *
 * Deliberate differences from the Python release:
 *  - English / Latin words are dropped (the original needs misaki + eSpeak).
 *  - Romanised-name replacement (nara_names.py) is not used.
 *  - Pieces are packed to a smaller limit so audio starts sooner.
 */
class Frontend(lexiconTsv: String, minedTsv: String) {

    private val lex = LinkedHashMap<String, String>()
    private val keys: List<String>
    private val minedVoicing = HashSet<Pair<String, String>>()
    private val minedSchwa = HashSet<Pair<String, String>>()

    init {
        for (raw in lexiconTsv.split('\n')) {
            val line = raw.trimEnd('\r')
            if (line.isEmpty() || line.startsWith("#")) continue
            val p = line.split('\t')
            if (p.size < 2) continue
            val k = normalize(p[0]).replace(OAW, PUA_S).replace(OAW2, PUA_S)
            lex[k] = p[1]
        }
        keys = lex.keys.sortedByDescending { it.length }
        for (raw in minedTsv.split('\n')) {
            val line = raw.trimEnd('\r')
            if (line.isEmpty() || line.startsWith("#")) continue
            val p = line.split('\t')
            if (p.size < 3) continue
            if (p[0] == "voicing") minedVoicing.add(Pair(p[1], p[2])) else minedSchwa.add(Pair(p[1], p[2]))
        }
    }

    // ------------------------------------------------------------------ public API

    /** Burmese number / percent / currency reading (my_numbers.verbalize). */
    fun verbalize(text: String): String {
        if (!DIGIT_ANY.containsMatchIn(text)) return text
        var t = WA_RUN.replace(text) { m ->
            val s = m.value
            if (BURMESE_DIGIT.containsMatchIn(s)) s.replace('\u101D', '\u1040') else s
        }
        t = NUM.replace(t) { say(it) }
        t = MULTI_SPACE.replace(t, " ")
        t = SPACE_BEFORE_PUNCT.replace(t, "")
        return t.trim()
    }

    /** split_speech(): sentences/clauses packed up to [limit] characters. */
    fun splitSpeech(text: String, limit: Int = 200): List<String> {
        val units = ArrayList<String>()
        for (sentence in splitAfter(text, "\u104B!?\u2026\n")) {
            for (c in splitAfter(sentence, "\u104A")) {
                var clause = c
                while (clause.length > limit) {
                    var cut = clause.lastIndexOf(' ', limit - 1)
                    if (cut <= 0) cut = limit
                    units.add(clause.substring(0, cut))
                    clause = clause.substring(cut).trim()
                }
                if (clause.trim().isNotEmpty()) units.add(clause.trim())
            }
        }
        val pieces = ArrayList<String>()
        var current = ""
        for (unit in units) {
            if (current.isNotEmpty() && current.length + 1 + unit.length > limit) {
                pieces.add(current)
                current = unit
            } else {
                current = "$current $unit".trim()
            }
        }
        if (current.isNotEmpty()) pieces.add(current)
        return pieces
    }

    /** Optional English pronunciation source (set once the dictionary is downloaded). */
    @Volatile var english: EnglishG2P? = null

    /** Text piece -> model symbol string (what synthesize.py feeds to the vocab). */
    fun phonemes(piece: String): String {
        val en = english
        val t = if (en != null) toTokens(piece, en) else LATIN_WORD.replace(piece, " ")
        return phonemize(t)
    }

    /** english.to_tokens(): Latin runs are replaced by their phonemes. */
    private fun toTokens(text: String, en: EnglishG2P): String {
        if (!LATIN_ANY.containsMatchIn(text)) return text
        val sb = StringBuilder()
        var last = 0
        for (m in LATIN_RUN.findAll(text)) {
            sb.append(text, last, m.range.first)
            sb.append(en.phonemes(m.value).replace("\u0329", "").trim())
            last = m.range.last + 1
        }
        sb.append(text, last, text.length)
        return MULTI_SPACE2.replace(sb.toString(), " ").trim()
    }

    // ------------------------------------------------------------------ normalize

    fun normalize(text: String): String {
        var t = text
        for ((a, b) in Tables.NORM_PRE) t = t.replace(a, b)
        t = STACK.replace(t) { it.groupValues[1] + ASAT }
        for ((a, b) in Tables.NORM_POST) t = t.replace(a, b)
        return t
    }

    // ------------------------------------------------------------------ syllables

    private fun isConsOrIndep(c: Char): Boolean =
        c in '\u1000'..'\u1021' || c in '\u1023'..'\u1027' || c == '\u1029' || c == '\u102A'

    private fun splitSyllables(text: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var i = 0
        val n = text.length
        while (i < n) {
            val ch = text[i]
            if (isConsOrIndep(ch)) {
                val isFinal = i + 1 < n && text[i + 1] == '\u103A'
                if (cur.isNotEmpty() && !isFinal) {
                    out.add(cur.toString())
                    cur.setLength(0)
                    cur.append(ch)
                } else {
                    cur.append(ch)
                }
                i++
            } else if (SPLIT_VOWELS.indexOf(ch) >= 0) {
                cur.append(ch)
                i++
            } else {
                if (cur.isNotEmpty()) {
                    out.add(cur.toString())
                    cur.setLength(0)
                }
                if (ch in 'A'..'Z' || ch in 'a'..'z') {
                    var j = i + 1
                    while (j < n && (text[j] in 'A'..'Z' || text[j] in 'a'..'z' || text[j] == '\'')) j++
                    out.add(text.substring(i, j))
                    i = j
                    continue
                }
                out.add(ch.toString())
                i++
            }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    private fun finalClass(c: Char): String? = when {
        Tables.F_K.indexOf(c) >= 0 -> "F_K"
        Tables.F_S.indexOf(c) >= 0 -> "F_S"
        Tables.F_T.indexOf(c) >= 0 -> "F_T"
        Tables.F_N.indexOf(c) >= 0 -> "F_N"
        Tables.F_NG.indexOf(c) >= 0 -> "F_NG"
        Tables.F_NY.indexOf(c) >= 0 -> "F_NY"
        else -> null
    }

    /** parse_syllable(); returns null where Python raises SylParseError. */
    private fun parseSyllable(s: String): String? {
        if (s.length == 1) {
            val ind = Tables.INDEP_SYL[s[0]]
            if (ind != null) return ind.first + "-" + ind.second + "-" + ind.third
        }
        val m = SYL_RE.matchEntire(s) ?: return null
        val g = m.groupValues
        val base = g[1][0]
        val meds = g[2]
        val fin = g[4]
        val anusvara = g[5]
        val visarga = g[7]
        val dot = g[6].isNotEmpty() || g[8].isNotEmpty()
        val vows = g[3].replace('\u102B', '\u102C')

        var onset = Tables.ONSET[base] ?: return null
        var medial = ""
        if (meds.indexOf('\u103E') >= 0) onset = Tables.ASPIRATE[onset] ?: onset
        if (meds.indexOf('\u103B') >= 0 || meds.indexOf('\u103C') >= 0) {
            val vp = Tables.VELAR_PAL[onset]
            if (vp != null) {
                onset = vp
            } else if (onset == "\u014B") {
                onset = "\u0272"
            } else if (onset == "\u0283") {
                // unchanged
            } else if (onset == "j") {
                // unchanged
            } else {
                medial = "j"
            }
        }
        var hasW = meds.indexOf('\u103D') >= 0
        val vkey = vows.toList().sortedBy { VOWEL_ORDER.indexOf(it) }.joinToString("")

        val rhyme: String
        var tone: String?
        if (fin.isNotEmpty() || anusvara.isNotEmpty()) {
            val fc = if (anusvara.isNotEmpty()) "F_N" else finalClass(fin[0])
            if (fin == "\u101A") {
                if (vkey == IO) {
                    rhyme = "o"
                } else {
                    rhyme = "\u025B"
                }
                tone = T3
            } else if (fin == "\u101C" || fin == "\u101F") {
                val vv = Tables.V[vkey] ?: return null
                rhyme = vv.first
                tone = T3
            } else if (fin == "\u100A") {
                rhyme = if (vkey == "\u1031") "\u025B" else "e"
                tone = T3
            } else if (fc != null) {
                val wkey = if (hasW && Tables.RHYME_CLOSED.containsKey(Pair("\u103D", fc)) && vkey.isEmpty()) "\u103D" else vkey
                if (wkey == "\u103D") hasW = false
                var r = Tables.RHYME_CLOSED[Pair(wkey, fc)] ?: return null
                if (base == '\u101D' && vkey.isEmpty()) {
                    r = when (r) {
                        "a\u0294" -> "\u028A\u0294"
                        "a\u0274" -> "\u028A\u0274"
                        else -> r
                    }
                }
                rhyme = r
                tone = if (r.endsWith("\u0294")) null else T3
            } else {
                return null
            }
        } else {
            val vv = Tables.V[vkey] ?: return null
            rhyme = vv.first
            tone = vv.second
        }
        if (tone != null) {
            if (visarga.isNotEmpty()) tone = T5 else if (dot) tone = TA
        }
        val parts = ArrayList<String>()
        parts.add(onset)
        if (hasW) medial = if (medial.isNotEmpty()) medial + "w" else "w"
        if (medial.isNotEmpty()) parts.add(medial)
        parts.add(rhyme)
        val tt = tone
        if (tt != null && tt.isNotEmpty()) parts.add(tt)
        return parts.joinToString("-")
    }

    private fun titReduces(chunk: List<String>, i: Int): Boolean {
        val nxt = chunk[i + 1]
        if (nxt in Tables.CLASSIFIERS) return true
        if (i > 0) {
            val a = chunk[i - 1]
            val b = chunk[i]
            if (i + 2 < chunk.size && chunk[i + 1] == a && chunk[i + 2] == b) return false
            if (i >= 3 && chunk[i - 3] == a && chunk[i - 2] == b) return false
            if (a == nxt) return false
        }
        return true
    }

    private fun applyMined(chunk: List<String>, parses: List<String?>): List<String?> {
        val out = parses.toMutableList()
        for (i in chunk.indices) {
            val syl = chunk[i]
            val p = parses[i] ?: continue
            val parts = p.split('-').toMutableList()
            if (syl == TIT && i + 1 < chunk.size && titReduces(chunk, i)) {
                out[i] = "t-\u0259"
                continue
            }
            if (i > 0 && minedVoicing.contains(Pair(chunk[i - 1], syl)) && Tables.VOICE_MAP.containsKey(parts[0])) {
                parts[0] = Tables.VOICE_MAP.getValue(parts[0])
                out[i] = parts.joinToString("-")
            }
            if (i + 1 < chunk.size && minedSchwa.contains(Pair(chunk[i + 1], syl))) {
                out[i] = parts[0] + "-\u0259"
            }
        }
        return out
    }

    // ------------------------------------------------------------------ g2p

    private fun isEn(tok: String): Boolean = tok.indexOf('-') < 0 && EN_CHARS.containsMatchIn(tok)

    private fun g2p(input: String): String {
        var text = normalize(input)
        text = text.replace(OAW, PUA_S).replace(OAW2, PUA_S)
        val out = ArrayList<String>()

        // lexicon pass
        val chunks = ArrayList<Pair<Boolean, String>>() // (isPhon, value)
        var i = 0
        val n = text.length
        while (i < n) {
            var hit: String? = null
            for (k in keys) {
                if (text.startsWith(k, i)) {
                    val j = i + k.length
                    if (j < n && MIDSYL.indexOf(text[j]) >= 0) continue
                    hit = k
                    break
                }
            }
            if (hit != null) {
                chunks.add(Pair(true, lex.getValue(hit)))
                i += hit.length
            } else {
                chunks.add(Pair(false, text[i].toString()))
                i++
            }
        }

        fun closeRun(runsyl: MutableList<String>) {
            if (runsyl.isEmpty()) return
            val parses = ArrayList<String?>()
            for (s in runsyl) {
                if (s == PUA_S) {
                    parses.add("\u0294-\u0254-\u02E7")
                } else if (s.indexOf(PUA) >= 0) {
                    val p = parseSyllable(s.replace(PUA_S, "\u1031\u102C"))
                    parses.add(if (p != null && p.endsWith("\u0254-\u02E5")) p.dropLast(3) + "\u0254-\u02E7" else p)
                } else {
                    parses.add(parseSyllable(s))
                }
            }
            for (p in applyMined(runsyl, parses)) if (p != null) out.add(p)
            runsyl.clear()
        }

        fun flush(buf: String) {
            val runsyl = ArrayList<String>()
            for (syl in splitSyllables(buf)) {
                if (isConsOrIndep(syl[0]) || syl.indexOf(PUA) >= 0) {
                    runsyl.add(syl)
                } else {
                    closeRun(runsyl)
                    val pu = PUNCT[syl]
                    if (pu != null) out.add(pu) else if (syl.isNotBlank()) out.add(syl) else out.add(" ")
                }
            }
            closeRun(runsyl)
        }

        val buf = StringBuilder()
        for ((isPhon, v) in chunks) {
            if (!isPhon) {
                buf.append(v)
            } else {
                if (buf.isNotEmpty()) {
                    flush(buf.toString())
                    buf.setLength(0)
                }
                out.add(v)
            }
        }
        if (buf.isNotEmpty()) flush(buf.toString())

        // merge / pause insertion
        val merged = ArrayList<String>()
        for ((idx, tok) in out.withIndex()) {
            if (tok == " ") {
                var nxt: String? = null
                for (j in idx + 1 until out.size) {
                    if (out[j] != " ") { nxt = out[j]; break }
                }
                if (merged.isNotEmpty() && merged.last() !in PUNCT_TOK && !isEn(merged.last()) &&
                    (nxt == null || !isEn(nxt))) {
                    merged.add(",")
                }
            } else if (tok == "," || tok == "." || tok == "?" || tok == "!") {
                if (merged.isNotEmpty() && merged.last() == ",") {
                    merged[merged.size - 1] = tok
                } else if (merged.isNotEmpty() && (merged.last() == "." || merged.last() == "?" || merged.last() == "!")) {
                    if (tok != merged.last()) merged.add(tok)
                } else {
                    merged.add(tok)
                }
            } else {
                merged.add(tok)
            }
        }
        while (merged.isNotEmpty() && merged.last() == ",") merged.removeAt(merged.size - 1)
        while (merged.isNotEmpty() && merged[0] in PUNCT_TOK) merged.removeAt(0)
        return merged.joinToString(" ")
    }

    // ------------------------------------------------------------------ phonemize

    private fun sylToChars(syl: String): String {
        val parts = syl.split('-')
        val tone = if (parts.last() == "\u02E7" || parts.last() == "\u02E5" || parts.last() == "\u02C0") parts.last() else null
        val core = if (tone != null) parts.dropLast(1) else parts
        val sb = StringBuilder()
        sb.append(Tables.CHAR[core[0]] ?: throw NoSuchElementException(core[0]))
        if (core.size > 2) {
            for (m in core.subList(1, core.size - 1)) sb.append(Tables.CHAR[m] ?: throw NoSuchElementException(m))
        }
        val split = Tables.RHYME_SPLIT[core.last()] ?: throw NoSuchElementException(core.last())
        for (c in split) sb.append(Tables.CHAR[c] ?: c)
        if (tone != null) sb.append(Tables.CHAR[tone] ?: throw NoSuchElementException(tone))
        return sb.toString()
    }

    fun phonemize(text: String): String {
        val phon = g2p(text)
        val out = ArrayList<String>()
        for (tok in phon.trim().split(WS)) {
            if (tok.isEmpty()) continue
            try {
                if (tok in PUNCT_TOK) {
                    out.add(tok)
                } else if (tok.indexOf('-') >= 0 || Tables.RHYME_SPLIT.containsKey(tok)) {
                    out.add(if (tok.indexOf('-') >= 0) sylToChars(tok) else tok)
                } else if (EN_CHARS.containsMatchIn(tok)) {
                    out.add(tok)
                } else if (tok[0].isLetter() || tok[0] == '_') {
                    out.add(sylToChars(tok))
                }
            } catch (e: Exception) {
                // Python: KeyError -> skip token
            }
        }
        return out.joinToString(" ")
    }

    // ------------------------------------------------------------------ numbers

    private fun belowLakh(n: Long): String {
        val s = n.toString()
        val parts = ArrayList<Pair<Int, Int>>()
        for ((i, ch) in s.withIndex()) {
            val d = ch - '0'
            val place = s.length - 1 - i
            if (d != 0) parts.add(Pair(d, place))
        }
        val sb = StringBuilder()
        for ((j, dp) in parts.withIndex()) {
            val d = dp.first
            val place = dp.second
            if (place == 0) { sb.append(Tables.DIGITS[d]); continue }
            var unit = Tables.PLACES.getValue(place)
            if (j < parts.size - 1) unit = Tables.CREAKY[unit] ?: unit
            val lead = if (d == 1 && place == 1 && j == 0) "" else Tables.DIGITS[d]
            sb.append(lead).append(unit)
        }
        return sb.toString()
    }

    private fun numberWords(n: Long): String {
        if (n == 0L) return Tables.DIGITS[0]
        if (n < 100000L) return belowLakh(n)
        val lakhs = n / 100000L
        val rest = n % 100000L
        return numberWords(lakhs) + Tables.S_LAKH + (if (rest != 0L) belowLakh(rest) else "")
    }

    private fun digitByDigit(s: String): String = s.map { Tables.DIGITS[it - '0'] }.joinToString(" ")

    private fun toAscii(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(if (c in '\u1040'..'\u1049') ('0' + (c - '\u1040')) else c)
        return sb.toString()
    }

    private fun say(m: MatchResult): String {
        val raw = toAscii(m.groups["int"]!!.value).replace(",", "")
        val frac = m.groups["frac"]?.value
        var out: String
        if ((raw.length > 1 && raw[0] == '0' && frac == null) || raw.length > 10) {
            out = digitByDigit(raw)
        } else {
            var n = raw.toLong()
            if (m.groups["k"] != null) n *= 1000L
            out = numberWords(n)
            if (frac != null) out += Tables.S_DASAMA + digitByDigit(toAscii(frac))
        }
        if (m.groups["pct"] != null) out += Tables.S_PERCENT
        if (m.groups["cur"] != null) out += Tables.S_KYAT
        return " $out "
    }

    private fun splitAfter(s: String, delims: String): List<String> {
        val res = ArrayList<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            cur.append(c)
            i++
            if (delims.indexOf(c) >= 0) {
                res.add(cur.toString())
                cur.setLength(0)
                while (i < s.length && s[i].isWhitespace()) i++
            }
        }
        res.add(cur.toString())
        return res
    }

    companion object {
        private const val ASAT = "\u103A"
        private const val PUA = '\uE001'
        private const val PUA_S = "\uE001"
        private const val OAW = "\u1031\u102C\u103A"
        private const val OAW2 = "\u1031\u102B\u103A"
        private const val TIT = "\u1010\u1005\u103A"
        private const val IO = "\u102D\u102F"
        private const val T3 = "\u02E7"
        private const val T5 = "\u02E5"
        private const val TA = "\u02C0"
        private const val VOWEL_ORDER = "\u1031\u102D\u102E\u102F\u1030\u102C\u1032"
        private const val MIDSYL = "\u102B\u102C\u102D\u102E\u102F\u1030\u1031\u1032\u1036\u1037\u1038\u103A\u103B\u103C\u103D\u103E"
        private const val SPLIT_VOWELS = MIDSYL + "\uE001"

        private val PUNCT = mapOf(
            "\u104A" to ",", "\u104B" to ".", "," to ",", "." to ".", "?" to "?", "!" to "!", " " to " "
        )
        private val PUNCT_TOK = setOf(",", ".", "?", "!")

        private val STACK = Regex("([\u1000-\u1021])\u1039")
        private val SYL_RE = Regex(
            "([\u1000-\u1021])([\u103B\u103C\u103D\u103E]*)([\u102B\u102C\u102D\u102E\u102F\u1030\u1031\u1032]*)" +
                "(?:([\u1000-\u1021])\u103A)?(\u1036?)(\u1037?)(\u1038?)(\u1037?)"
        )
        private val EN_CHARS = Regex("[A-Za-z\u00E6\u00F0\u03B8\u014B\u0292\u0250-\u02AF\u1D7B\u02C8\u02CC\u02D0]")
        private val LATIN_WORD = Regex("[A-Za-z]+(?:['\u2019\\-][A-Za-z]+)*")
        private val WS = Regex("\\s+")
        private val LATIN_ANY = Regex("[A-Za-z]")
        private val LATIN_RUN = Regex("[A-Za-z][A-Za-z'\\-. ]*[A-Za-z]|[A-Za-z]")
        private val MULTI_SPACE2 = Regex(" {2,}")

        private const val D = "[0-9\u1040-\u1049]"
        private val DIGIT_ANY = Regex(D)
        private val BURMESE_DIGIT = Regex("[\u1040-\u1049]")
        private val WA_RUN = Regex("(?:[\u1040-\u1049]|\u101D(?![\u102B-\u103E]))+")
        private val NUM = Regex(
            "(?<int>$D{1,3}(?:,$D{3})+|$D+)(?:\\.(?<frac>$D+))?(?<k>[kK](?![A-Za-z]))?(?<pct>\\s?%)?" +
                "(?<cur>\\s?(?:Ks|KS|ks|MMK|mmk|Kyats?|kyats?)\\b)?"
        )
        private val MULTI_SPACE = Regex("[ \\t]{2,}")
        private val SPACE_BEFORE_PUNCT = Regex(" (?=[!?.,\u104B\u104A])")
    }
}
