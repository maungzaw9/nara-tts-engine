package com.nara.tts

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EnglishG2PTest {
    private val g = EnglishG2P(mapOf("hello" to "h\u0259l\u02C8O", "cat" to "k\u02C8\u00E6t"))

    @Test
    fun dictionaryAndFallback() {
        assertEquals("h\u0259l\u02C8O", g.phonemes("Hello"))
        assertEquals("k\u02C8\u00E6ts", g.phonemes("cats"))
        assertTrue(g.phonemes("Samsung").isNotEmpty())
        assertTrue(g.phonemes("NASA").contains(" "))
        assertTrue(g.phonemes("iPhone YouTube").isNotEmpty())
        println("samsung=" + g.phonemes("Samsung") + " facebook=" + g.phonemes("Facebook") + " nasa=" + g.phonemes("NASA"))
    }

    @Test
    fun frontendUsesEnglish() {
        val assets = File("src/main/assets")
        val fe = Frontend(File(assets, "lexicon_exceptions.tsv").readText(), File(assets, "mined_rules.tsv").readText())
        val without = fe.phonemes("hello")
        fe.english = g
        val with = fe.phonemes("hello")
        println("without=[" + without + "] with=[" + with + "]")
        assertTrue(with.isNotEmpty())
    }
}
