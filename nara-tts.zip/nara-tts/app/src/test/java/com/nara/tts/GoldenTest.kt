package com.nara.tts

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/** Compares the Kotlin frontend with output recorded from the original Python frontend. */
class GoldenTest {
    private val assets = File("src/main/assets")
    private val fe = Frontend(
        File(assets, "lexicon_exceptions.tsv").readText(),
        File(assets, "mined_rules.tsv").readText()
    )

    private fun unesc(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    '\\' -> sb.append('\\')
                    else -> sb.append(c).append(s[i + 1])
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }

    @Test
    fun matchesPython() {
        val failures = ArrayList<String>()
        var total = 0
        for (line in File("src/test/resources/golden.tsv").readLines()) {
            if (line.isEmpty()) continue
            val p = line.split('\t')
            val kind = p[0]
            val input = unesc(p[1])
            val expected = unesc(p[2])
            total++
            val actual = try {
                when {
                    kind == "P" -> fe.phonemize(input)
                    kind == "N" -> fe.verbalize(input)
                    kind.startsWith("S") -> fe.splitSpeech(input, kind.substring(1).toInt()).joinToString("|")
                    else -> "?"
                }
            } catch (e: Exception) {
                "EXCEPTION " + e
            }
            if (actual != expected) failures.add("$kind | $input | expected=$expected | actual=$actual")
        }
        println("golden cases: $total, failures: ${failures.size}")
        failures.take(15).forEach { println("FAIL: $it") }
        assertTrue("${failures.size} of $total golden cases differ", failures.isEmpty())
    }
}
